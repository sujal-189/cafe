<?php
session_start();
if (!isset($_SESSION['user_logged_in'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php'; // Use $conn from here (MySQLi connection)

// Fetch user orders
$user_id = $_SESSION['user_id'];
$sql = "SELECT o.*, m.name AS menu_name 
        FROM orders o 
        JOIN menus m ON o.menu_id = m.id 
        WHERE o.user_id = $user_id 
        ORDER BY o.created_at DESC";

$result = mysqli_query($conn, $sql);
$ordersByDate = [];
$total = 0;
$totalItems = 0;

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $date = date('F d, Y', strtotime($row['created_at']));
        $ordersByDate[$date][] = $row;
        $total += $row['total_price'];
        $totalItems += $row['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Orders</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 30px;
            padding-bottom: 50px;
        }
        .orders-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 30px;
        }
        .page-header {
            border-bottom: 2px solid #e9ecef;
            margin-bottom: 25px;
            padding-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .table-container {
            margin-bottom: 30px;
            border-radius: 8px;
            overflow: hidden;
        }
        .orders-table thead {
            background-color: #007bff;
            color: white;
        }
        .order-item:hover {
            background-color: #f8f9fa;
        }
        .order-date {
            font-size: 0.9rem;
            white-space: nowrap;
        }
        .total-price {
            font-weight: 600;
            color: #28a745;
        }
        .navigation-btns {
            margin-top: 15px;
        }
        .footer-btn {
            padding: 10px 25px;
            border-radius: 6px;
            font-weight: 500;
            margin-right: 10px;
        }
        .orders-summary {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
        }
        .summary-item {
            text-align: center;
            padding: 0 10px;
        }
        .summary-value {
            font-size: 1.5rem;
            font-weight: 600;
            color: #007bff;
        }
        .summary-label {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .empty-orders {
            text-align: center;
            padding: 40px 0;
        }
        .empty-orders-icon {
            font-size: 4rem;
            color: #dee2e6;
            margin-bottom: 20px;
        }
        .date-heading {
            font-size: 1.25rem;
            font-weight: bold;
            margin-top: 40px;
            margin-bottom: 10px;
            color: #343a40;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="orders-container">
        <div class="page-header">
            <h2><i class="fas fa-shopping-bag mr-2"></i>Your Orders</h2>
            <div>
                <a href="dashboard.php" class="btn btn-outline-primary"><i class="fas fa-home mr-2"></i>Dashboard</a>
            </div>
        </div>

        <?php if (count($ordersByDate) > 0): ?>
            <div class="orders-summary">
                <div class="summary-item">
                    <div class="summary-value"><?php echo array_sum(array_map('count', $ordersByDate)); ?></div>
                    <div class="summary-label">Total Orders</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">₹<?php echo number_format($total, 2); ?></div>
                    <div class="summary-label">Total Spent</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value"><?php echo $totalItems; ?></div>
                    <div class="summary-label">Items Ordered</div>
                </div>
            </div>

            <?php foreach ($ordersByDate as $date => $orders): ?>
                <div class="date-heading"><?php echo $date; ?></div>
                <div class="table-container">
                    <table class="table table-striped orders-table">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Menu Item</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Time</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr class="order-item">
                                    <td><strong><?php echo $order['id']; ?></strong></td>
                                    <td><?php echo $order['menu_name']; ?></td>
                                    <td><?php echo $order['quantity']; ?> ×</td>
                                    <td class="total-price">₹<?php echo number_format($order['total_price'], 2); ?></td>
                                    <td class="order-date">
                                        <?php 
                                            $time = new DateTime($order['created_at']);
                                            echo $time->format('h:i A'); 
                                        ?>
                                    </td>
                                    <td>
                                        <a href="remove_order.php?id=<?php echo $order['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to remove this order?');">Remove</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>

        <?php else: ?>
            <div class="empty-orders">
                <div class="empty-orders-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <h4>You haven't placed any orders yet</h4>
                <p class="text-muted">Visit our menu to place your first order</p>
                <a href="dashboard.php" class="btn btn-primary mt-3">Browse Menu</a>
            </div>
        <?php endif; ?>

        <div class="navigation-btns">
            <a href="dashboard.php" class="btn btn-info footer-btn">
                <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
            </a>
            <a href="logout.php" class="btn btn-secondary footer-btn">
                <i class="fas fa-sign-out-alt mr-2"></i>Logout
            </a>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
</body>
</html>

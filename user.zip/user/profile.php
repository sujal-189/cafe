<?php
session_start();

include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
} else {
    echo "User not found.";
    exit();
}

mysqli_stmt_close($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - <?php echo htmlspecialchars($user['full_name'] ?? 'User'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4f46e5;
            --secondary-color: #e5e7eb;
            --accent-color: #f59e0b;
            --text-dark: #1f2937;
            --text-light: #6b7280;
            --bg-light: #f8fafc;
        }

        body {
            background: linear-gradient(135deg, var(--bg-light) 0%, #e2e8f0 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }

        .profile-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #7c3aed 100%);
            color: white;
            padding: 3rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 30px 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .profile-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .profile-card:hover {
            transform: translateY(-5px);
        }

        .profile-image {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            border: 6px solid white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .profile-image:hover {
            transform: scale(1.05);
        }

        .info-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border-left: 4px solid var(--primary-color);
        }

        .info-item {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
            padding: 0.5rem 0;
        }

        .info-item i {
            color: var(--primary-color);
            width: 20px;
            margin-right: 1rem;
        }

        .btn-custom {
            background: linear-gradient(135deg, var(--primary-color) 0%, #7c3aed 100%);
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            color: white;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(79, 70, 229, 0.3);
            color: white;
        }

        .btn-secondary-custom {
            background: white;
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin-left: 1rem;
        }

        .btn-secondary-custom:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-2px);
        }

        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            margin-bottom: 1rem;
        }

        .stats-number {
            font-size: 2rem;
            font-weight: bold;
            display: block;
        }

        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }

        .fade-in {
            animation: fadeIn 0.8s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .social-links a {
            display: inline-block;
            width: 40px;
            height: 40px;
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            margin: 0 5px;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(79, 70, 229, 0.4);
            color: white;
        }

    </style>
</head>
<body>
  
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <i class="fas fa-user-circle me-2"></i>Profile
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php"><i class="fas fa-home me-1"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php"><i class="fas fa-cog me-1"></i>Settings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="profile-header mt-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-4 text-center">
                    <?php if (!empty($user['profile_picture'])): ?>
                        <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                             alt="Profile Picture" class="profile-image">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/200x200/4f46e5/ffffff?text=<?php echo strtoupper(substr($user['full_name'] ?? 'U', 0, 1)); ?>" 
                             alt="Profile Picture" class="profile-image">
                    <?php endif; ?>
                </div>
                <div class="col-md-8">
                    <h1 class="display-4 fw-bold mb-3">
                        <?php echo htmlspecialchars($user['full_name'] ?? 'User Name'); ?>
                    </h1>
                    <p class="lead mb-4">
                        <?php echo htmlspecialchars($user['bio'] ?? 'Welcome to my profile!'); ?>
                    </p>
                    <div class="d-flex flex-wrap">
                        <a href="edit_profile.php" class="btn-custom">
                            <i class="fas fa-edit me-2"></i>Edit Profile
                        </a>
                        <a href="change_password.php" class="btn-secondary-custom">
                            <i class="fas fa-lock me-2"></i>Change Password
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <!-- Profile Information -->
            <div class="col-lg-8">
                <div class="info-card fade-in">
                    <h3 class="mb-4"><i class="fas fa-info-circle me-2"></i>Personal Information</h3>
                    
                    <div class="info-item">
                        <i class="fas fa-user"></i>
                        <div>
                            <strong>Username:</strong>
                            <span class="ms-2"><?php echo htmlspecialchars($user['username'] ?? 'N/A'); ?></span>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <strong>Email:</strong>
                            <span class="ms-2"><?php echo htmlspecialchars($user['email'] ?? 'N/A'); ?></span>
                        </div>
                    </div>
                    
                    <?php if (!empty($user['phone'])): ?>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <strong>Phone:</strong>
                            <span class="ms-2"><?php echo htmlspecialchars($user['phone']); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['location'])): ?>
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Location:</strong>
                            <span class="ms-2"><?php echo htmlspecialchars($user['location']); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['website'])): ?>
                    <div class="info-item">
                        <i class="fas fa-globe"></i>
                        <div>
                            <strong>Website:</strong>
                            <a href="<?php echo htmlspecialchars($user['website']); ?>" target="_blank" class="ms-2">
                                <?php echo htmlspecialchars($user['website']); ?>
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="info-item">
                        <i class="fas fa-calendar-alt"></i>
                        <div>
                            <strong>Member Since:</strong>
                            <span class="ms-2">
                                <?php 
                                if (!empty($user['created_at'])) {
                                    echo date('F j, Y', strtotime($user['created_at']));
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Social Links -->
                <div class="info-card fade-in">
                    <h3 class="mb-4"><i class="fas fa-share-alt me-2"></i>Social Links</h3>
                    <div class="social-links">
                        <?php if (!empty($user['facebook'])): ?>
                            <a href="<?php echo htmlspecialchars($user['facebook']); ?>" target="_blank">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($user['twitter'])): ?>
                            <a href="<?php echo htmlspecialchars($user['twitter']); ?>" target="_blank">
                                <i class="fab fa-twitter"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($user['linkedin'])): ?>
                            <a href="<?php echo htmlspecialchars($user['linkedin']); ?>" target="_blank">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($user['instagram'])): ?>
                            <a href="<?php echo htmlspecialchars($user['instagram']); ?>" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (empty($user['facebook']) && empty($user['twitter']) && empty($user['linkedin']) && empty($user['instagram'])): ?>
                            <p class="text-muted">No social links added yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Stats -->
                <div class="stats-card fade-in">
                    <span class="stats-number"><?php echo rand(15, 99); ?></span>
                    <small>Profile Views</small>
                </div>
                
                <div class="stats-card fade-in">
                    <span class="stats-number"><?php echo rand(5, 25); ?></span>
                    <small>Connections</small>
                </div>
                
                <div class="stats-card fade-in">
                    <span class="stats-number"><?php echo rand(1, 10); ?></span>
                    <small>Posts</small>
                </div>

                <!-- Quick Actions -->
                <div class="info-card fade-in">
                    <h5 class="mb-3"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="upload_avatar.php" class="btn btn-outline-primary">
                            <i class="fas fa-camera me-2"></i>Upload Avatar
                        </a>
                        <a href="privacy_settings.php" class="btn btn-outline-secondary">
                            <i class="fas fa-shield-alt me-2"></i>Privacy Settings
                        </a>
                        <a href="account_settings.php" class="btn btn-outline-info">
                            <i class="fas fa-cog me-2"></i>Account Settings
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center py-4 mt-5">
        <div class="container">
            <p class="text-muted">&copy; 2025 User Profile System. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Add smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add fade-in animation on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        document.querySelectorAll('.fade-in').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });

        // Profile image hover effect
        const profileImage = document.querySelector('.profile-image');
        if (profileImage) {
            profileImage.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.05) rotate(5deg)';
            });
            
            profileImage.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1) rotate(0deg)';
            });
        }
    </script>
</body>
</html>
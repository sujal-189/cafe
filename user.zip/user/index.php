<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Panel - Cafe Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Welcome to the User Panel</h1>
    <p class="lead">Please choose an option below:</p>
    <div class="mt-4">
        <a href="login.php" class="btn btn-primary btn-lg">User  Login</a>
        <a href="register.php" class="btn btn-success btn-lg">User  Register</a>
    </div>
</div>
</body>
</html>
<?php
session_start();

include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id = ?");

if ($stmt) { // Check if prepare was successful
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
    } else {
        echo "User not found.";
        exit();
    }
    mysqli_stmt_close($stmt);
} else {
    // Handle the error
    echo "Error preparing statement: " . mysqli_error($conn);
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $bio = trim($_POST['bio']);
    $phone = trim($_POST['phone'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $website = trim($_POST['website'] ?? '');
    
    // Social media links
    $facebook = trim($_POST['facebook'] ?? '');
    $twitter = trim($_POST['twitter'] ?? '');
    $linkedin = trim($_POST['linkedin'] ?? '');
    $instagram = trim($_POST['instagram'] ?? '');

    // Validation
    if (empty($full_name)) {
        $error_message = "Full name is required.";
    } elseif (empty($email)) {
        $error_message = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        // Check if email is already taken by another user
        $email_check = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ? AND id != ?");
        
        if ($email_check) {
            mysqli_stmt_bind_param($email_check, "si", $email, $user_id);
            mysqli_stmt_execute($email_check);
            $email_result = mysqli_stmt_get_result($email_check);
            
            if (mysqli_num_rows($email_result) > 0) {
                $error_message = "Email is already taken by another user.";
            } else {
                // Handle profile picture upload
                $profile_picture = $user['profile_picture']; // Keep existing picture
                
                if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['size'] > 0) {
                    $upload_dir = "uploads/";
                    
                    // Create uploads directory if it doesn't exist
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_extension = strtolower(pathinfo($_FILES["profile_picture"]["name"], PATHINFO_EXTENSION));
                    $new_filename = uniqid() . '_' . $user_id . '.' . $file_extension;
                    $target_file = $upload_dir . $new_filename;

                    // Validate image
                    $check = getimagesize($_FILES["profile_picture"]["tmp_name"]);
                    if ($check === false) {
                        $error_message = "File is not an image.";
                    } elseif ($_FILES["profile_picture"]["size"] > 5000000) { // 5MB limit
                        $error_message = "File is too large. Maximum size is 5MB.";
                    } elseif (!in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                        $error_message = "Only JPG, JPEG, PNG & GIF files are allowed.";
                    } else {
                        // Try to upload file
                        if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                            // Delete old profile picture if exists
                            if (!empty($user['profile_picture']) && file_exists($user['profile_picture'])) {
                                unlink($user['profile_picture']);
                            }
                            $profile_picture = $target_file;
                        } else {
                            $error_message = "Sorry, there was an error uploading your file.";
                        }
                    }
                }

                // If no errors, update the database
                if (empty($error_message)) {
                    $update_sql = "UPDATE users SET 
                        full_name = ?, 
                        email = ?, 
                        bio = ?, 
                        phone = ?, 
                        location = ?, 
                        website = ?, 
                        facebook = ?, 
                        twitter = ?, 
                        linkedin = ?, 
                        instagram = ?, 
                        profile_picture = ?,
                        updated_at = NOW()
                        WHERE id = ?";
                    
                    $update_stmt = mysqli_prepare($conn, $update_sql);
                    
                    if ($update_stmt) {
                        mysqli_stmt_bind_param($update_stmt, "sssssssssssi", 
                            $full_name, $email, $bio, $phone, $location, $website, 
                            $facebook, $twitter, $linkedin, $instagram, $profile_picture, $user_id
                        );

                        if (mysqli_stmt_execute($update_stmt)) {
                            $success_message = "Profile updated successfully!";
                            // Refresh user data
                            $user['full_name'] = $full_name;
                            $user['email'] = $email;
                            $user['bio'] = $bio;
                            $user['phone'] = $phone;
                            $user['location'] = $location;
                            $user['website'] = $website;
                            $user['facebook'] = $facebook;
                            $user['twitter'] = $twitter;
                            $user['linkedin'] = $linkedin;
                            $user['instagram'] = $instagram;
                            $user['profile_picture'] = $profile_picture;
                        } else {
                            $error_message = "Error updating profile: " . mysqli_error($conn);
                        }
                        mysqli_stmt_close($update_stmt);
                    } else {
                         $error_message = "Error preparing update statement: " . mysqli_error($conn);
                    }
                }
            }
            mysqli_stmt_close($email_check);
        } else {
            echo "Error preparing email check statement: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - <?php echo htmlspecialchars($user['full_name'] ?? 'User'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #4f46e5;
            --secondary-color: #e5e7eb;
            --accent-color: #f59e0b;
            --text-dark: #1f2937;
            --text-light: #6b7280;
            --bg-light: #f8fafc;
            --success-color: #10b981;
            --error-color: #ef4444;
        }

        body {
            background: linear-gradient(135deg, var(--bg-light) 0%, #e2e8f0 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }

        .edit-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #7c3aed 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 30px 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .form-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            padding: 2.5rem;
            margin-bottom: 2rem;
        }

        .form-section {
            border-left: 4px solid var(--primary-color);
            padding-left: 1.5rem;
            margin-bottom: 2rem;
        }

        .form-section h4 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .form-control, .form-select {
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            padding: 12px 15px;
            transition: all 0.3s ease;
            font-size: 16px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(79, 70, 229, 0.15);
        }

        .form-label {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .btn-custom {
            background: linear-gradient(135deg, var(--primary-color) 0%, #7c3aed 100%);
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            color: white;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(79, 70, 229, 0.3);
            color: white;
        }

        .btn-secondary-custom {
            background: white;
            border: 2px solid var(--text-light);
            color: var(--text-light);
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-secondary-custom:hover {
            border-color: var(--primary-color);
            color: var(--primary-color);
            transform: translateY(-2px);
        }

        .profile-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--primary-color);
            margin-bottom: 1rem;
        }

        .file-upload-wrapper {
            position: relative;
            display: inline-block;
            cursor: pointer;
            width: 100%;
        }

        .file-upload-input {
            position: absolute;
            left: -9999px;
        }

        .file-upload-button {
            display: inline-block;
            padding: 12px 20px;
            background: var(--accent-color);
            color: white;
            border-radius: 10px;
            transition: all 0.3s ease;
            width: 100%;
            text-align: center;
        }

        .file-upload-button:hover {
            background: #d97706;
            transform: translateY(-2px);
        }

        .alert-custom {
            border-radius: 15px;
            padding: 1rem 1.5rem;
            margin-bottom: 2rem;
            border: none;
        }

        .alert-success-custom {
            background: linear-gradient(135deg, var(--success-color) 0%, #059669 100%);
            color: white;
        }

        .alert-error-custom {
            background: linear-gradient(135deg, var(--error-color) 0%, #dc2626 100%);
            color: white;
        }

        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }

        .social-input-group {
            position: relative;
        }

        .social-input-group .form-control {
            padding-left: 50px;
        }

        .social-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            z-index: 10;
        }

        .fade-in {
            animation: fadeIn 0.8s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .progress-bar-custom {
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color) 0%, #7c3aed 100%);
        }

    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="profile.php">
                <i class="fas fa-user-edit me-2"></i>Edit Profile
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php"><i class="fas fa-user me-1"></i>View Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php"><i class="fas fa-home me-1"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <div class="edit-header mt-5">
        <div class="container">
            <div class="row align-items-center">
                                <div class="col-md-6">
                    <h1 class="display-5 fw-bold mb-2">Edit Your Profile</h1>
                    <p class="lead mb-0">Update your information and make your profile shine</p>
                </div>
                <div class="col-md-6 text-end">
                    <div class="progress-bar-custom"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Success/Error Messages -->
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success-custom alert-custom fade-in" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-error-custom alert-custom fade-in" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data" id="profileForm">
            <div class="row">
                <div class="col-lg-8">
                    <!-- Basic Information -->
                    <div class="form-card fade-in">
                        <div class="form-section">
                            <h4><i class="fas fa-user me-2"></i>Basic Information</h4>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="full_name" class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" 
                                           value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="location" class="form-label">Location</label>
                                    <input type="text" class="form-control" id="location" name="location" 
                                           value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>" 
                                           placeholder="City, Country">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="website" class="form-label">Website</label>
                                <input type="url" class="form-control" id="website" name="website" 
                                       value="<?php echo htmlspecialchars($user['website'] ?? ''); ?>" 
                                       placeholder="https://yourwebsite.com">
                            </div>

                            <div class="mb-3">
                                <label for="bio" class="form-label">Bio</label>
                                <textarea class="form-control" id="bio" name="bio" rows="4" 
                                          placeholder="Tell us about yourself..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                                <small class="text-muted">Maximum 500 characters</small>
                            </div>
                        </div>
                    </div>

                    <!-- Social Media Links -->
                    <div class="form-card fade-in">
                        <div class="form-section">
                            <h4><i class="fas fa-share-alt me-2"></i>Social Media Links</h4>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="facebook" class="form-label">Facebook</label>
                                    <div class="social-input-group">
                                        <i class="fab fa-facebook-f social-icon"></i>
                                        <input type="url" class="form-control" id="facebook" name="facebook" 
                                               value="<?php echo htmlspecialchars($user['facebook'] ?? ''); ?>" 
                                               placeholder="Facebook profile URL">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="twitter" class="form-label">Twitter</label>
                                    <div class="social-input-group">
                                        <i class="fab fa-twitter social-icon"></i>
                                        <input type="url" class="form-control" id="twitter" name="twitter" 
                                               value="<?php echo htmlspecialchars($user['twitter'] ?? ''); ?>" 
                                               placeholder="Twitter profile URL">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="linkedin" class="form-label">LinkedIn</label>
                                    <div class="social-input-group">
                                        <i class="fab fa-linkedin-in social-icon"></i>
                                        <input type="url" class="form-control" id="linkedin" name="linkedin" 
                                               value="<?php echo htmlspecialchars($user['linkedin'] ?? ''); ?>" 
                                               placeholder="LinkedIn profile URL">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="instagram" class="form-label">Instagram</label>
                                    <div class="social-input-group">
                                        <i class="fab fa-instagram social-icon"></i>
                                        <input type="url" class="form-control" id="instagram" name="instagram" 
                                               value="<?php echo htmlspecialchars($user['instagram'] ?? ''); ?>" 
                                               placeholder="Instagram profile URL">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4">
                    <!-- Profile Picture -->
                    <div class="form-card fade-in">
                        <div class="form-section">
                            <h4><i class="fas fa-camera me-2"></i>Profile Picture</h4>
                            
                            <div class="text-center">
                                <?php if (!empty($user['profile_picture'])): ?>
                                    <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                         alt="Profile Picture" class="profile-preview" id="imagePreview">
                                <?php else: ?>
                                    <img src="https://via.placeholder.com/120x120/4f46e5/ffffff?text=<?php echo strtoupper(substr($user['full_name'] ?? 'U', 0, 1)); ?>" 
                                         alt="Profile Picture" class="profile-preview" id="imagePreview">
                                <?php endif; ?>
                                
                                <div class="file-upload-wrapper">
                                    <input type="file" class="file-upload-input" id="profile_picture" name="profile_picture" 
                                           accept="image/*" onchange="previewImage(this)">
                                    <label for="profile_picture" class="file-upload-button">
                                        <i class="fas fa-upload me-2"></i>Choose New Photo
                                    </label>
                                </div>
                                
                                <small class="text-muted d-block mt-2">
                                    Max size: 5MB<br>
                                    Formats: JPG, PNG, GIF
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Save Actions -->
                    <div class="form-card fade-in">
                        <div class="form-section">
                            <h4><i class="fas fa-save me-2"></i>Save Changes</h4>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-custom">
                                    <i class="fas fa-save me-2"></i>Update Profile
                                </button>
                                <a href="profile.php" class="btn btn-secondary-custom">
                                    <i class="fas fa-times me-2"></i>Cancel
                                </a>
                            </div>
                            
                            <div class="mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Changes will be saved immediately after clicking "Update Profile"
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Image preview function
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Bio character counter
        const bioTextarea = document.getElementById('bio');
        const maxLength = 500;
        
        bioTextarea.addEventListener('input', function() {
            if (this.value.length > maxLength) {
                this.value = this.value.substring(0, maxLength);
            }
        });

        // Form validation
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            const fullName = document.getElementById('full_name').value.trim();
            const email = document.getElementById('email').value.trim();
            
            if (!fullName) {
                alert('Full name is required');
                e.preventDefault();
                return false;
            }
            
            if (!email) {
                alert('Email is required');
                e.preventDefault();
                return false;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Updating...';
            submitBtn.disabled = true;
            
            // Re-enable after 5 seconds in case of errors
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 5000);
        });

        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert-custom');
            alerts.forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-20px)';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);

        // Add fade-in animation on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        document.querySelectorAll('.fade-in').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
    </script>
</body>
</html>

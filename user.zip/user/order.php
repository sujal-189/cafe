<?php
session_start();
if (!isset($_SESSION['user_logged_in'])) {
    header('Location: login.php');
    exit();
}

include '../includes/db.php'; // Must include mysqli connection as $conn

$menu_id = $_GET['id'];
$menu_sql = "SELECT * FROM menus WHERE id = $menu_id";
$menu_result = mysqli_query($conn, $menu_sql);
$menu = mysqli_fetch_assoc($menu_result);

if (!$menu) {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quantity = $_POST['quantity'];
    $user_id = $_SESSION['user_id'];
    $total_price = $menu['price'] * $quantity;

    $order_sql = "INSERT INTO orders (user_id, menu_id, quantity, total_price) VALUES ('$user_id', '$menu_id', '$quantity', '$total_price')";
    mysqli_query($conn, $order_sql);

    header('Location: dashboard.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order: <?php echo htmlspecialchars($menu['name']); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 30px;
            padding-bottom: 50px;
        }
        .order-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 30px;
        }
        .page-header {
            border-bottom: 2px solid #e9ecef;
            margin-bottom: 25px;
            padding-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .menu-details {
            background-color: #e9ecef;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
        }
        .menu-icon {
            background-color: #007bff;
            color: white;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-right: 20px;
        }
        .menu-info h4 {
            margin-bottom: 5px;
        }
        .menu-price {
            font-weight: 600;
            color: #28a745;
            font-size: 1.3rem;
        }
        .quantity-input {
            max-width: 150px;
        }
        .submit-section {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
        .price-preview {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 25px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .price-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
        }
        .price-row.total {
            border-top: 2px solid #dee2e6;
            margin-top: 8px;
            padding-top: 15px;
            font-weight: 600;
            font-size: 1.2rem;
        }
        .total-value {
            color: #28a745;
        }
        .input-with-icon {
            position: relative;
        }
        .btn-quantity {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            padding: 0;
            line-height: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .quantity-controls {
            display: flex;
            align-items: center;
        }
        .quantity-display {
            width: 60px;
            text-align: center;
            font-weight: 600;
            font-size: 1.2rem;
            margin: 0 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="order-container">
                <div class="page-header">
                    <h2><i class="fas fa-shopping-cart mr-2"></i>Place Order</h2>
                    <a href="dashboard.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left mr-2"></i>Back</a>
                </div>
                
                <div class="menu-details">
                    <div class="menu-icon">
                        <i class="fas fa-utensils"></i>
                    </div>
                    <div class="menu-info">
                        <h4><?php echo htmlspecialchars($menu['name']); ?></h4>
                        <div class="menu-price">₹<?php echo number_format($menu['price'], 2); ?> per item</div>
                    </div>
                </div>
                
                <form method="POST" id="orderForm">
                    <div class="form-group">
                        <label for="quantity"><i class="fas fa-cubes mr-2"></i>Select Quantity:</label>
                        <div class="quantity-controls">
                            <button type="button" class="btn btn-outline-secondary btn-quantity" id="decreaseQuantity"><i class="fas fa-minus"></i></button>
                            <input type="hidden" name="quantity" id="quantity" value="1">
                            <div class="quantity-display" id="quantityDisplay">1</div>
                            <button type="button" class="btn btn-outline-secondary btn-quantity" id="increaseQuantity"><i class="fas fa-plus"></i></button>
                        </div>
                    </div>
                    
                    <div class="price-preview">
                        <h5><i class="fas fa-receipt mr-2"></i>Order Summary</h5>
                        <div class="price-row">
                            <div>Price per item</div>
                            <div>₹<?php echo number_format($menu['price'], 2); ?></div>
                        </div>
                        <div class="price-row">
                            <div>Quantity</div>
                            <div id="summaryQuantity">1</div>
                        </div>
                        <div class="price-row total">
                            <div>Total Price</div>
                            <div class="total-value" id="totalPrice">₹<?php echo number_format($menu['price'], 2); ?></div>
                        </div>
                    </div>
                    
                    <div class="submit-section">
                        <a href="dashboard.php" class="btn btn-secondary"><i class="fas fa-times mr-2"></i>Cancel</a>
                        <button type="submit" class="btn btn-success btn-lg"><i class="fas fa-check-circle mr-2"></i>Confirm Order</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const price = <?php echo $menu['price']; ?>;
        const quantityInput = document.getElementById('quantity');
        const quantityDisplay = document.getElementById('quantityDisplay');
        const summaryQuantity = document.getElementById('summaryQuantity');
        const totalPrice = document.getElementById('totalPrice');
        const decreaseBtn = document.getElementById('decreaseQuantity');
        const increaseBtn = document.getElementById('increaseQuantity');
        
        function updatePrice() {
            const quantity = parseInt(quantityInput.value);
            const total = (price * quantity).toFixed(2);
            totalPrice.textContent = '₹' + total;
            quantityDisplay.textContent = quantity;
            summaryQuantity.textContent = quantity;
        }
        
        decreaseBtn.addEventListener('click', function() {
            const currentVal = parseInt(quantityInput.value);
            if (currentVal > 1) {
                quantityInput.value = currentVal - 1;
                updatePrice();
            }
        });
        
        increaseBtn.addEventListener('click', function() {
            const currentVal = parseInt(quantityInput.value);
            quantityInput.value = currentVal + 1;
            updatePrice();
        });
    });

    
</script>
</body>
</html>
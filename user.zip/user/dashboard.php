<?php
session_start();

include '../includes/db.php';  

if (!isset($_SESSION['user_logged_in'])) {
    header('Location: login.php');
    exit();
}

$menus = [];
$sql = "SELECT * FROM menus";
$result = mysqli_query($conn, $sql);
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $menus[] = $row;
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 30px;
            padding-bottom: 50px;
        }
        .dashboard-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 30px;
        }
        .dashboard-header {
            border-bottom: 2px solid #e9ecef;
            margin-bottom: 25px;
            padding-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .table-container {
            margin-bottom: 30px;
            border-radius: 8px;
            overflow: hidden;
        }
        .dashboard-table {
            margin-bottom: 0;
        }
        .dashboard-table thead {
            background-color: #343a40;
            color: white;
        }
        .menu-price {
            font-weight: 600;
            color: #28a745;
        }
        .action-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .order-btn {
            border-radius: 20px;
            padding: 6px 20px;
            font-weight: 500;
        }
        .footer-buttons {
            margin-top: 10px;
        }
        .footer-btn {
            padding: 10px 25px;
            border-radius: 6px;
            font-weight: 500;
            margin-right: 10px;
        }
        .welcome-user {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
        }
        .menu-item {
            transition: all 0.2s ease;
        }
        .menu-item:hover {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="dashboard-container">
        <div class="dashboard-header">
            <h2><i class="fas fa-utensils mr-2"></i>User Dashboard</h2>
            <div>
                <a href="logout.php" class="btn btn-outline-secondary"><i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
            </div>
        </div>
        
        <div class="welcome-user">
            <h5><i class="fas fa-user-circle mr-2"></i>Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : 'users'; ?></h5>
            <p class="mb-0">Cafe menu and place your order today.</p>
        </div>
        
        <h3><i class="fas fa-clipboard-list mr-2"></i>Available Menu Items</h3>
        
        <div class="table-container">
            <table class="table table-striped dashboard-table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Item Name</th>
                        <th scope="col">Price</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($menus)): ?>
                        <tr>
                            <td colspan="4" class="text-center py-4">No menu items available at the moment.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($menus as $menu): ?>
                            <tr class="menu-item">
                                <td><?php echo $menu['id']; ?></td>
                                <td><strong><?php echo $menu['name']; ?></strong></td>
                                <td class="menu-price">₹<?php echo number_format($menu['price'], 2); ?></td>
                                <td>
                                    <a href="order.php?id=<?php echo $menu['id']; ?>" class="btn btn-primary order-btn">
                                        <i class="fas fa-shopping-cart mr-2"></i>Order
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="footer-buttons">
            <a href="orders.php" class="btn btn-info footer-btn">
                <i class="fas fa-list-alt mr-2"></i>View My Orders
            </a>
            <a href="profile.php" class="btn btn-secondary footer-btn">
                <i class="fas fa-user-cog mr-2"></i>My Profile
            </a>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
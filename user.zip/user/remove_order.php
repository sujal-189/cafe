<?php
session_start();
if (!isset($_SESSION['user_logged_in'])) {
    header('Location: login.php');
    exit();
}

include '../includes/db.php'; // Make sure this file sets $conn = mysqli_connect(...)

if (isset($_GET['id'])) {
    $order_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // Escape values to prevent SQL injection
    $order_id = mysqli_real_escape_string($conn, $order_id);
    $user_id = mysqli_real_escape_string($conn, $user_id);

    // Delete order that belongs to the logged-in user
    $query = "DELETE FROM orders WHERE id = '$order_id' AND user_id = '$user_id'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_affected_rows($conn) > 0) {
        header('Location: orders.php?msg=Order+removed+successfully');
    } else {
        header('Location: orders.php?error=Unable+to+remove+order');
    }
    exit();
} else {
    header('Location: orders.php');
    exit();
}
?>

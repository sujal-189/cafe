<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "cafe_management");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the menu ID from the URL
$id = $_GET['id'];

// Escape the ID for safety
$id = mysqli_real_escape_string($conn, $id);

// First, delete related records from the orders table
$deleteOrdersQuery = "DELETE FROM orders WHERE menu_id = '$id'";
mysqli_query($conn, $deleteOrdersQuery);

// Then, delete the menu item
$deleteMenuQuery = "DELETE FROM menus WHERE id = '$id'";
mysqli_query($conn, $deleteMenuQuery);

// Redirect back to menu list
header("Location: menu_list.php");
exit();
?>

<?php
session_start();
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = 'admin'; // Hardcoded for simplicity
    $password = 'admin189'; // Hardcoded for simplicity

    if ($_POST['username'] == $username && $_POST['password'] == $password) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: dashboard.php');
        exit();
    } else {
        $error = "Invalid credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #2a3042;
            padding-top: 50px;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.25);
        }
        .card-header {
            background-color: #343a40;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 1.5rem;
        }
        .btn-primary {
            background-color: #3a4253;
            border-color: #3a4253;
            padding: 0.75rem 1rem;
        }
        .btn-primary:hover {
            background-color: #212529;
            border-color: #212529;
        }
        .form-control:focus {
            border-color: #3a4253;
            box-shadow: 0 0 0 0.25rem rgba(58, 66, 83, 0.25);
        }
        .input-group-text {
            background-color: #f8f9fa;
        }
        .admin-logo {
            font-size: 3rem;
            text-align: center;
            margin-bottom: 15px;
            color: #fff;
        }
        .admin-logo i {
            background-color: #343a40;
            padding: 15px;
            border-radius: 50%;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .alert {
            border-radius: 6px;
            margin-top: 15px;
        }
        .admin-badge {
            background-color: #dc3545;
            color: white;
            padding: 3px 10px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .separator {
            height: 1px;
            background-color: rgba(255,255,255,0.1);
            margin: 20px 0;
        }
        .secure-badge {
            display: inline-block;
            padding: 4px 8px;
            background-color: rgba(25, 135, 84, 0.1);
            color: #198754;
            border-radius: 4px;
            font-size: 12px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-9">
                <div class="admin-logo">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="card">
                    <div class="card-header text-center">
                        <h3 class="mb-0">Admin Portal</h3>
                        <span class="admin-badge">Restricted</span>
                        <p class="text-white-50 mb-0">Authorized personnel only</p>
                    </div>
                    <div class="card-body p-4">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="username" class="form-label">Admin Username</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter admin username" required>
                                    <div class="invalid-feedback">
                                        Username is required.
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Admin Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-key"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter admin password" required>
                                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <div class="invalid-feedback">
                                        Password is required.
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-lock-open me-2"></i>Sign In
                                </button>
                            </div>
                            
                            <div class="text-center">
                                <a href="#" class="text-decoration-none">Forgot password?</a>
                                <p class="mt-2 mb-0"><a href="../index.php" class="text-decoration-none">
                                    <i class="fas fa-arrow-left me-1"></i>Return to homepage
                                </a></p>
                            </div>
                            
                            <div class="text-center">
                                <div class="secure-badge">
                                    <i class="fas fa-shield-alt me-1"></i> Secure connection
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="text-center text-white-50 mt-3">
                    <small>&copy; 2025 Admin Control Panel</small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()

        // Toggle password visibility
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Cafe Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1 class="mt-5">Welcome to the Admin Panel</h1>
    <p class="lead">Please log in to manage the cafe.</p>
    <div class="mt-4">
        <a href="login.php" class="btn btn-primary btn-lg">Admin Login</a>
    </div>
</div>
</body>
</html>
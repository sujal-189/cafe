<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Connect to database (MySQLi)
$conn = mysqli_connect("localhost", "root", "", "cafe_management");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//  Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);

    $sql = "INSERT INTO menus (name, price) VALUES ('$name', '$price')";
    if (mysqli_query($conn, $sql)) {
        header('Location: menu_list.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Menu Item</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 30px;
        }
        .form-card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background-color: white;
            padding: 30px;
        }
        .page-header {
            color: #343a40;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e9ecef;
        }
        .btn-add {
            padding: 10px 25px;
            font-weight: 600;
        }
        .price-input-group {
            position: relative;
        }
        .price-input-group:before {
            content: "₹";
            position: absolute;
            left: 10px;
            top: 10px;
            z-index: 10;
            font-weight: 600;
        }
        .price-input {
            padding-left: 25px;
        }
        .form-submit-section {
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="form-card">
                <div class="page-header">
                    <h2 class="text-center"><i class="fas fa-utensils mr-2"></i>Add Menu Item</h2>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="name"><i class="fas fa-hamburger mr-2"></i>Menu Item Name:</label>
                        <input type="text" class="form-control form-control-lg" id="name" name="name" placeholder="Enter item name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="price"><i class="fas fa-tag mr-2"></i>Price:</label>
                        <div class="price-input-group">
                            <input type="number" step="0.01" min="0" class="form-control form-control-lg price-input" id="price" name="price" placeholder="0.00" required>
                        </div>
                    </div>
                    
                    <div class="form-submit-section">
                        <a href="menu_list.php" class="btn btn-secondary"><i class="fas fa-arrow-left mr-2"></i>Back</a>
                        <button type="submit" class="btn btn-success btn-add"><i class="fas fa-plus mr-2"></i>Add Item</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
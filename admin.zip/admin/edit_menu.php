<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Include DB connection (procedural mysqli)
include '../includes/db.php'; // Make sure this file defines $conn = mysqli_connect(...)

// Get menu ID from URL
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Fetch the existing menu item
    $query = "SELECT * FROM menus WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $menu = mysqli_fetch_assoc($result);
    } else {
        echo "Menu item not found!";
        exit();
    }
} else {
    echo "No menu ID provided!";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);

    $updateQuery = "UPDATE menus SET name = '$name', price = '$price' WHERE id = '$id'";
    if (mysqli_query($conn, $updateQuery)) {
        header("Location: menu_list.php?msg=Menu+updated+successfully");
        exit();
    } else {
        echo "Error updating menu: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 30px;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border: none;
            border-radius: 10px;
        }
        .card-header {
            background-color: #4e73df;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        .btn-primary {
            background-color: #4e73df;
            border-color: #4e73df;
        }
        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2e59d9;
        }
        .btn-secondary {
            background-color: #858796;
            border-color: #858796;
        }
        .form-control:focus {
            border-color: #bac8f3;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        .price-input-group {
            position: relative;
        }
        .price-input-group .form-control {
            padding-left: 30px;
        }
        .price-input-group .input-group-text {
            position: absolute;
            z-index: 10;
            left: 10px;
            top: 9px;
            background: transparent;
            border: none;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-edit mr-2"></i>Edit Menu Item</h4>
                        <a href="menu_list.php" class="btn btn-sm btn-light"><i class="fas fa-arrow-left mr-1"></i>Back to List</a>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST">
                            <div class="form-group">
                                <label for="name"><i class="fas fa-utensils mr-1"></i>Menu Item Name:</label>
                                <input type="text" class="form-control form-control-lg" id="name" name="name" value="<?php echo htmlspecialchars($menu['name']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="price"><i class="fas fa-tag mr-1"></i>Price:</label>
                                <div class="price-input-group">
                                    <span class="input-group-text">₹</span>
                                    <input type="number" step="0.01" min="0" class="form-control form-control-lg" id="price" name="price" value="<?php echo htmlspecialchars($menu['price']); ?>" required>
                                </div>
                            </div>
                            <div class="form-group mt-4 text-center">
                                <button type="submit" class="btn btn-primary btn-lg px-5"><i class="fas fa-save mr-2"></i>Update Menu Item</button>
                                <a href="menu_list.php" class="btn btn-secondary btn-lg ml-2"><i class="fas fa-times mr-2"></i>Cancel</a>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer bg-light text-center text-muted">
                        <small>Last edited: <?php echo date('F j, Y, g:i a'); ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
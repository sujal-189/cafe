<?php
// Include DB connection
include '../includes/db.php'; // make sure this file sets $conn = mysqli_connect(...);

// Validate order ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid order ID.");
}

$order_id = (int) $_GET['id'];

// Escape order ID for safety
$order_id = mysqli_real_escape_string($conn, $order_id);

// Query to get order details using simple MySQLi
$sql = "SELECT 
            o.id AS order_id,
            u.id AS user_id,
            u.username,
            m.id AS menu_id,
            m.name AS menu_name,
            o.quantity,
            o.total_price,
            o.created_at
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN menus m ON o.menu_id = m.id
        WHERE o.id = '$order_id'";

$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Order not found.");
}

$order = mysqli_fetch_assoc($result);

// Calculate unit price
$unit_price = $order['total_price'] / $order['quantity'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Order Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 30px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .card-header {
            background-color: #4e73df;
            color: white;
            border-bottom: none;
            font-weight: 500;
        }
        .table {
            margin-bottom: 0;
        }
        .table td, .table th {
            padding: 1rem;
            vertical-align: middle;
        }
        .table th {
            font-weight: 600;
            width: 35%;
            color: #495057;
            background-color: rgba(0,0,0,0.03);
        }
        .price-badge {
            font-size: 1rem;
            padding: 0.5rem 0.75rem;
        }
        .btn-back {
            padding: 0.5rem 1.5rem;
            font-weight: 500;
        }
        .card-footer {
            background-color: #fff;
            border-top: 1px solid rgba(0,0,0,0.05);
        }
        .user-info {
            display: flex;
            align-items: center;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            background-color: #4e73df;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
        }
        .order-actions {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .order-actions .btn {
            padding: 0.375rem 1rem;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center py-3">
                        <h4 class="mb-0"><i class="fas fa-shopping-cart mr-2"></i>Order Details</h4>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <th scope="row">Order ID</th>
                                    <td><strong><?php echo htmlspecialchars($order['order_id']); ?></strong></td>
                                </tr>
                                <tr>
                                    <th scope="row">User</th>
                                    <td>
                                        <div class="user-info">
                                            <div class="user-avatar">
                                                <i class="fas fa-user-circle"></i>
                                            </div>
                                            <div>
                                                <?php echo htmlspecialchars($order['username']); ?>
                                                <div class="text-muted small">User ID: <?php echo htmlspecialchars($order['user_id']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Menu Item</th>
                                    <td>
                                        <a href="view_menu.php?id=<?php echo htmlspecialchars($order['menu_id']); ?>">
                                            <?php echo htmlspecialchars($order['menu_name']); ?>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Unit Price</th>
                                    <td>
                                        <span class="badge badge-light price-badge">
                                            <i class="fas fa-rupee-sign mr-1"></i><?php echo number_format($unit_price, 2); ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Quantity</th>
                                    <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Total Price</th>
                                    <td>
                                        <span class="badge badge-success price-badge">
                                            <i class="fas fa-rupee-sign mr-1"></i><?php echo number_format($order['total_price'], 2); ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Order Date</th>
                                    <td>
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php 
                                            $date = new DateTime($order['created_at']);
                                            echo $date->format('M d, Y - h:i A'); 
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer py-3">
                        <div class="order-actions">
                            <a href="user_orders.php" class="btn btn-primary btn-back">
                                <i class="fas fa-arrow-left mr-2"></i>Back to
                            </a>
                            <a href="print_receipt.php?id=<?php echo htmlspecialchars($order['order_id']); ?>" class="btn btn-secondary">
                                <i class="fas fa-print mr-2"></i>Print Receipt
                            </a>
                            <a href="#" class="btn btn-info" title="Status update functionality not available">
                                <i class="fas fa-cog mr-2"></i>Actions
                            </a>
                        </div>
                    </div>
                </div>
                <div class="text-center mt-3 text-muted">
                    <small>Order Management System</small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
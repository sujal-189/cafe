<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

include '../includes/db.php'; // Make sure this file defines $conn (mysqli connection)

// Fetch all orders with user and menu details
$sql = "SELECT 
            o.id AS order_id,
            u.id AS user_id,
            u.username,
            m.name AS menu_name,
            o.quantity,
            o.total_price,
            o.created_at
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN menus m ON o.menu_id = m.id
        ORDER BY o.created_at DESC";

$result = mysqli_query($conn, $sql);

// Initialize variables
$orders = [];
$totalRevenue = 0;
$totalItems = 0;
$users = [];

if ($result && mysqli_num_rows($result) > 0) {
    while ($order = mysqli_fetch_assoc($result)) {
        $orders[] = $order;
        $totalRevenue += $order['total_price'];
        $totalItems += $order['quantity'];
        $users[$order['user_id']] = $order['username'];
    }
}

$totalOrders = count($orders);
$uniqueCustomers = count($users);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All User Orders - Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: var(--sidebar-width);
            padding: 0;
            z-index: 100;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #343a40;
            transition: all 0.3s;
        }
        .sidebar-sticky {
            height: 100vh;
            padding-top: 0.5rem;
            overflow-x: hidden;
            overflow-y: auto;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
            padding: 0.75rem 1rem;
            font-weight: 500;
            border-left: 4px solid transparent;
        }
        .sidebar .nav-link:hover {
            color: #fff;
            border-left-color: #4e73df;
            background-color: rgba(78, 115, 223, 0.1);
        }
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .sidebar-header {
            padding: 1.5rem 1rem;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-divider {
            height: 0;
            margin: 0.5rem 0;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: all 0.3s;
        }
        .navbar {
            background-color: white;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            padding: 0.75rem 1rem;
        }
        .navbar .nav-item .nav-link {
            color: #555;
        }
        .navbar-brand {
            font-weight: 700;
            color: #343a40;
        }
        .card {
            border-radius: 8px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            border: none;
            margin-bottom: 24px;
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid #e3e6f0;
            padding: 0.75rem 1.25rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .card-header h5 {
            margin-bottom: 0;
            font-weight: 600;
        }
        .btn-icon {
            padding: 0.375rem 0.75rem;
            border-radius: 0.25rem;
        }
        .stat-card {
            border-left: 4px solid;
        }
        .stat-card.primary {
            border-left-color: #4e73df;
        }
        .stat-card.success {
            border-left-color: #1cc88a;
        }
        .stat-card.info {
            border-left-color: #36b9cc;
        }
        .stat-card.warning {
            border-left-color: #f6c23e;
        }
        .stat-card .stat-icon {
            font-size: 2rem;
            opacity: 0.3;
        }
        .table {
            vertical-align: middle;
        }
        .table-action-buttons {
            white-space: nowrap;
        }
        .logout-button {
            position: absolute;
            bottom: 20px;
            width: calc(100% - 2rem);
            margin: 0 1rem;
        }
        .admin-profile {
            text-align: center;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .admin-avatar {
            height: 70px;
            width: 70px;
            border-radius: 50%;
            margin: 0 auto 1rem;
            background-color: #4e73df;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
        }
        .admin-profile p {
            color: rgba(255, 255, 255, 0.6);
            margin-bottom: 0;
            font-size: 0.8rem;
        }
        .admin-profile h6 {
            color: white;
            margin-bottom: 0.25rem;
        }
        .badge-status {
            padding: 0.35em 0.65em;
            font-size: 0.75em;
        }
        .dropdown-menu {
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            border: none;
        }
        .toggle-sidebar {
            display: none;
        }

        body {
            background-color: #f8f9fa;
            padding-bottom: 30px;
        }
        .admin-header {
            background-color: #343a40;
            color: white;
            padding: 15px 0;
            margin-bottom: 30px;
        }
        .admin-title {
            font-weight: 600;
            margin-bottom: 0;
        }
        .page-title {
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid #dee2e6;
            padding-bottom: 10px;
        }
        .stats-container {
            margin-bottom: 30px;
        }
        .stat-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
            transition: transform 0.2s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .orders-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 30px;
        }
        .table-header {
            background-color: #343a40;
            color: white;
        }
        .action-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .btn-admin {
            font-weight: 500;
            padding: 8px 20px;
            border-radius: 4px;
        }
        .order-date {
            font-size: 0.9rem;
        }
        .order-price {
            font-weight: 600;
            color: #28a745;
        }
        .search-bar {
            margin-bottom: 20px;
        }
        .user-badge {
            background-color: #e9ecef;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        .empty-orders {
            text-align: center;
            padding: 50px 0;
        }
        .empty-icon {
            font-size: 4rem;
            color: #dee2e6;
            margin-bottom: 20px;
        }
        .pagination-container {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
<!-- Sidebar -->
<div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h4><i class="fas fa-utensils me-2"></i>Food Admin</h4>
        </div>
        
        <div class="admin-profile">
            <div class="admin-avatar">
                <i class="fas fa-user"></i>
            </div>
            <h6>Admin User</h6>
            <p>System Administrator</p>
        </div>
        
        <hr class="sidebar-divider">
        
        <div class="sidebar-sticky">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="menu_list.php">
                        <i class="fas fa-hamburger"></i>
                        Menu Management
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_list.php">
                        <i class="fas fa-users"></i>
                        User Management
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_orders.php">
                        <i class="fas fa-shopping-cart"></i>
                        Orders Management
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar"></i>
                        Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </li>
            </ul>
            
            <a href="logout.php" class="btn btn-danger logout-button">
                <i class="fas fa-sign-out-alt me-2"></i>Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="main-content">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg mb-4">
            <button class="btn btn-link toggle-sidebar me-3" id="toggleSidebar">
                <i class="fas fa-bars"></i>
            </button>
            <span class="navbar-brand">Dashboard</span>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-bell fa-fw"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><h6 class="dropdown-header">Notifications</h6></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">New order received</a></li>
                            <li><a class="dropdown-item" href="#">New user registered</a></li>
                            <li><a class="dropdown-item" href="#">System update completed</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <span class="me-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                            <i class="fas fa-user-circle fa-fw"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw me-2 text-gray-400"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw me-2 text-gray-400"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>

    <div class="container">
        <h2 class="page-title"><i class="fas fa-shopping-cart mr-2"></i>Order Management</h2>
        
        <div class="stats-container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card text-center">
                        <div class="stat-icon text-primary">
                            <i class="fas fa-shopping-bag"></i>
                        </div>
                        <div class="stat-value"><?php echo $totalOrders; ?></div>
                        <div class="stat-label">Total Orders</div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card text-center">
                        <div class="stat-icon text-success">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-value">₹<?php echo number_format($totalRevenue, 2); ?></div>
                        <div class="stat-label">Total Revenue</div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card text-center">
                        <div class="stat-icon text-info">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-value"><?php echo $uniqueCustomers; ?></div>
                        <div class="stat-label">Unique Customers</div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card text-center">
                        <div class="stat-icon text-warning">
                            <i class="fas fa-box"></i>
                        </div>
                        <div class="stat-value"><?php echo $totalItems; ?></div>
                        <div class="stat-label">Items Sold</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="orders-card">
            <div class="action-buttons">
                <h3 class="mb-0"><i class="fas fa-list mr-2"></i>Order List</h3>
                <div>
                    <a href="#" class="btn btn-success btn-admin ml-2"><i class="fas fa-file-excel mr-2"></i>Export CSV</a>
                </div>
            </div>
            
            <div class="search-bar">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                    <input type="text" class="form-control" id="orderSearch" placeholder="Search by username, menu item...">
                </div>
            </div>
            
            <?php if (count($orders) > 0) : ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="ordersTable">
                        <thead class="table-header">
                            <tr>
                                <th> Order ID </th>
                                <th><i class="fas fa-user mr-1"></i> User</th>
                                <th><i class="fas fa-utensils mr-1"></i> Menu Item</th>
                                <th><i class="fas fa-cubes mr-1"></i> Quantity</th>
                                <th><i class="fas fa-dollar-sign mr-1"></i> </th>
                                <th><i class="fas fa-calendar-alt mr-1"></i> Order Date</th>
                                <th><i class="fas fa-cog mr-1"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($order['order_id']); ?></strong></td>
                                <td>
                                    <span class="user-badge">
                                        <i class="fas fa-user-circle mr-1"></i>
                                        <?php echo htmlspecialchars($order['username']); ?>
                                        <small class="text-muted">(ID: <?php echo htmlspecialchars($order['user_id']); ?>)</small>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($order['menu_name']); ?></td>
                                <td class="text-center"><?php echo htmlspecialchars($order['quantity']); ?></td>
                                <td class="order-price">₹<?php echo number_format($order['total_price'], 2); ?></td>
                                <td class="order-date">
                                    <?php 
                                        $date = new DateTime($order['created_at']);
                                        echo $date->format('M d, Y - h:i A');
                                    ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm">
                                        <a href="view_orders.php?id=<?php echo $order['order_id']; ?>" class="btn btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="print_receipt.php?id=<?php echo $order['order_id']; ?>" class="btn btn-secondary">
                                            <i class="fas fa-print"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="pagination-container">
                    <nav aria-label="Page navigation">
                        <ul class="pagination">
                            <li class="page-item disabled"><a class="page-link" href="#"><i class="fas fa-chevron-left"></i></a></li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a></li>
                        </ul>
                    </nav>
                </div>
            <?php else: ?>
                <div class="empty-orders">
                    <div class="empty-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <h4>No Orders Found</h4>
                    <p class="text-muted">There are no orders in the system yet.</p>
                </div>
            <?php endif; ?> 
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
    <script>
        // Simple search functionality
        $(document).ready(function(){
            $("#orderSearch").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#ordersTable tbody tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>
</body>
</html>
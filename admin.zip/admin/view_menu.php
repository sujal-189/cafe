<?php
// ✅ Connect to the database using mysqli procedural
include '../includes/db.php'; // This file should define $conn = mysqli_connect(...);

// ✅ Validate the menu ID from query string
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid menu ID.");
}

$menu_id = (int) $_GET['id'];

//  Escape the input (not strictly necessary after casting to int, but good practice)
$menu_id = mysqli_real_escape_string($conn, $menu_id);

//  Prepare and run the SQL query
$sql = "SELECT id, name, price, created_at FROM menus WHERE id = '$menu_id'";
$result = mysqli_query($conn, $sql);

//  Fetch the result
if ($result && mysqli_num_rows($result) > 0) {
    $menu = mysqli_fetch_assoc($result);
} else {
    die("Menu item not found.");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Menu Item</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 30px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .card-header {
            background-color: #20c997;
            color: white;
            border-bottom: none;
            font-weight: 500;
        }
        .table {
            margin-bottom: 0;
        }
        .table td, .table th {
            padding: 1rem;
            vertical-align: middle;
        }
        .table th {
            font-weight: 600;
            width: 35%;
            color: #495057;
            background-color: rgba(0,0,0,0.03);
        }
        .price-badge {
            font-size: 1rem;
            padding: 0.5rem 0.75rem;
        }
        .btn-back {
            padding: 0.5rem 1.5rem;
            font-weight: 500;
        }
        .card-footer {
            background-color: #fff;
            border-top: 1px solid rgba(0,0,0,0.05);
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center py-3">
                        <h4 class="mb-0"><i class="fas fa-utensils mr-2"></i>Menu Item Details</h4>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <th scope="row">ID</th>
                                    <td><?php echo htmlspecialchars($menu['id']); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Name</th>
                                    <td class="font-weight-bold"><?php echo htmlspecialchars($menu['name']); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Price</th>
                                    <td>
                                        <span class="badge badge-success price-badge">
                                            <i class="fas fa-rupee-sign mr-1"></i><?php echo number_format($menu['price'], 2); ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Created At</th>
                                    <td>
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php echo htmlspecialchars($menu['created_at']); ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer text-center py-3">
                        <a href="menu_list.php" class="btn btn-primary btn-back">
                            <i class="fas fa-arrow-left mr-2"></i>Back to Menu List
                        </a>
                    </div>
                </div>
                <div class="text-center mt-3 text-muted">
                    <small>Menu Management System</small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>